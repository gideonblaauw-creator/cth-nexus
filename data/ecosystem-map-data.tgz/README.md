# Ecosystem map – extraction from Canva (19 Oct 2026)

Actors: 286 (all organizations; 0 persons named in the designs). Relations: 75.

Website: 275/286 (96%) have one; 247 (86%) verified responding (2xx/3xx/403-bot-block). Others timed out from box (unverified, not necessarily dead).
LinkedIn: 0% — no persons in any mapping; org LinkedIn not collected.

## Counts per country

- Peru: 201
- El Salvador: 77
- Colombia: 8

## Country × category

- Colombia / finance: 1
- Colombia / funder: 1
- Colombia / government: 4
- Colombia / international: 2
- El Salvador / academia: 5
- El Salvador / accelerator: 6
- El Salvador / chamber: 5
- El Salvador / corporate: 7
- El Salvador / finance: 8
- El Salvador / funder: 8
- El Salvador / government: 8
- El Salvador / international: 17
- El Salvador / media: 8
- El Salvador / ngo_foundation: 3
- El Salvador / startup: 2
- Peru / academia: 15
- Peru / accelerator: 32
- Peru / chamber: 9
- Peru / corporate: 15
- Peru / finance: 14
- Peru / funder: 25
- Peru / government: 35
- Peru / international: 26
- Peru / media: 4
- Peru / ngo_foundation: 20
- Peru / startup: 6

## Startups and Nexus cards

- Black Soldier Fly Logistics (Peru): needs Nexus card
- YakuSmart (Peru): card https://nexus.cleantechhub.net/s/yakusmart
- VIGIA (Peru): card https://nexus.cleantechhub.net/s/vigia
- UQHU (Peru): needs Nexus card
- Yakufil (Peru): needs Nexus card
- Rebike Up (Peru): needs Nexus card
- IAGROS (El Salvador): needs Nexus card
- Recicla503 (El Salvador): needs Nexus card

### needs Nexus card

- Black Soldier Fly Logistics (Peru)
- UQHU (Peru)
- Yakufil (Peru)
- Rebike Up (Peru)
- IAGROS (El Salvador)
- Recicla503 (El Salvador)

## Gaps

- Guatemala: no Canva actor mapping found.
- Costa Rica: no Canva actor mapping found (only CCE Hub incubation program deck).
- Colombia: no CTH actor mapping; only generic "Complete Ecosystem Map" energy deck (8 institutions).
- Peru cohort startup names (REIN Hub 2025/2026, 26 ventures) are in images, not text; only 6 named in text captured. Read thumbnails DAHXkXRp9uc_p* to transcribe.
- Canva API exposes no page boundaries in text, so `page` is null.
- No persons → LinkedIn requirement unmet; would need staff/mentor sources.
- A few design links are wrong (e.g. Programa para Bionegocios/INAIGEM cards link to fiaes.org.sv; Scotiabank card links to arca.com.sv; PRODUCE card links to midagri) — corrected in actors.json.

Files: actors.json, relations.json, designs.json, thumbnails/ (page PNG thumbnails, 596px)